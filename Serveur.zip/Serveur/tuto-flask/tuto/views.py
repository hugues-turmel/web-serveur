from flask_login import logout_user
from hashlib import sha256
from .models import User
from wtforms import PasswordField
from .app import app, db
from flask import render_template, redirect, url_for, request
from .models import get_sample, get_book_detail, get_author, Author, Book, get_all_author, exist_author, get_all_book
from flask_wtf import FlaskForm
from wtforms import StringField, HiddenField, SelectField
from wtforms.validators import DataRequired
from flask_login import login_user, current_user
import sys
import logging
from sqlalchemy import func 


@app.route("/")
def home():
    return render_template(
        "home.html",
        title="Tiny Amazon",
        books=get_sample())


@app.route("/author/<int:id>")
def one_author(id):
    author = get_author(id)
    return render_template(
        "home.html",
        title="Livres de " + author.name,
        books=author.books
    )

@app.route("/author/search")
def search_author(author_name):
    author = exist_author(author_name)
    return render_template(
        "home.html",
        title="Livres de " + author.name,
        books=author.books
    )

@app.route("/detail/<bookid>")
def detail(bookid):
    return render_template(
        "detail.html",
        title="Détail",
        book=get_book_detail(int(bookid))
    )


class AuthorForm(FlaskForm):
    id      = HiddenField('id')
    name    = StringField('Nom', validators=[DataRequired()])
    # [validators.InputRequired(), validators.Length(min=2, max=25,
    # message="Le nom doit comprendre entre 2 et 25 char"),
    # validators.Regexp('^[a-zA-Z]+$'), message="le contenue doit contenir seulement des lettres"])

class BookForm(FlaskForm):
    author_list =   [(author.name) for author in get_all_author()]
    title       =   StringField(    'Title', validators=[DataRequired()])
    picture     =   StringField(  'Picture', validators=[DataRequired()])
    price       =   StringField(    'Price', validators=[DataRequired()])
    author      =   SelectField(   'Author', validators=[DataRequired()], choices=author_list)

class ModifyForm(FlaskForm):
    author_list =   [(author.name) for author in get_all_author()]
    book_list   =   [(book.title) for book in get_all_book()]
    author      =   SelectField(            'Author', validators=[DataRequired()] ,choices=author_list)
    book        =   SelectField(        'Book Title', validators=[DataRequired()] ,choices=book_list)
    new_title   =   StringField(    'New Book Title', validators=[DataRequired()])
    new_price   =   StringField(         'New Price', validators=[DataRequired()])

class DeleteBookForm(FlaskForm):
    book_list   =   [(book.title) for book in get_all_book()]
    author_list =   [(author.name) for author in get_all_author()]
    book        =   SelectField(        'Book Title', validators=[DataRequired()] ,choices=book_list)
    author      =   SelectField(            'Author', validators=[DataRequired()] ,choices=author_list)

@app.route("/edit/author/")
@app.route("/edit/author/<int:id>")
def edit_author(id=None):
    nom = None
    if id is not None:
        a = get_author(id)
        nom = a.name
    else:
        a = None
    f = AuthorForm(id=id, name=nom)
    return render_template(
        "edit_author.html",
        author=a, form=f
    )

@app.route("/add/book/")
def add_book(id=None):
    f = BookForm()
    return render_template(
        "add_book.html",
        form=f
    )

@app.route("/delete/book/")
def delete_book(id=None):
    f = DeleteBookForm()
    return render_template(
        "delete_book.html",
        form=f
    )

@app.route("/save/book/", methods=("POST",))
def save_book():
    f = BookForm()
    if f.validate_on_submit():
        b_title         = str(f.title.data)
        b_picture       = str(f.picture.data)
        b_price         = float(f.price.data)
        b_author_name   = str(f.author.data)
        print('Title :   {}'.format(b_title),       file=sys.stderr)
        print('Picture : {}'.format(b_picture),     file=sys.stderr)
        print('Price :   {}'.format(b_price),       file=sys.stderr)
        print('Auteur :  {}'.format(b_author_name), file=sys.stderr)
        a = Author.query.filter(Author.name==b_author_name).one()
        book_list   =   [(book.id) for book in get_all_book()]
        print('book_list : {}'.format(max(book_list)), file=sys.stderr)
        if b_title != "" and b_picture != "" and b_price != "" and b_author_name != "":
            b = Book(
                id          = max(book_list)+1,
                author_id   = a.id,
                author      = a,
                price       = b_price,
                title       = b_title,
                img         = b_picture 
            )
            db.session.add(b)
            db.session.commit()
        return redirect(url_for('one_author', id=a.id))
    return render_template(
        "add_book.html",
        form=f
    )

@app.route("/save/delete/book/", methods=("POST",))
def save_delete_book():
    f = DeleteBookForm()
    if f.validate_on_submit():
        book_title = str(f.book.data)
        book_author_name = str(f.author.data)
        author = Author.query.filter(Author.name==book_author_name).one()
        if book_title != "" and book_author_name != "":
            author = Author.query.filter(Author.name==book_author_name).one()
            Book.query.filter(Book.title==book_title and Book.author==author).delete()
            db.session.commit()
        return redirect(url_for('one_author', id=author.id))
    return render_template(
        "delete_book.html",
        form=f
    )

@app.route("/modify/book/")
def modify_book(id=None):
    f = ModifyForm()
    return render_template(
        "modify_book.html",
        form=f
    )

@app.route("/save/modification/", methods=("POST",))
def save_modification():
    f = ModifyForm()
    if f.validate_on_submit():
        b_author     = str(f.author.data)
        b_title      = str(f.book.data)
        b_new_title  = str(f.new_title.data)
        b_new_price  = float(f.new_price.data)
        print('b_author :      {}'.format(b_author),        file=sys.stderr)
        print('b_title :       {}'.format(b_title),         file=sys.stderr)
        print('b_new_title :   {}'.format(b_new_title),     file=sys.stderr)
        print('b_new_price :   {}'.format(b_new_price),     file=sys.stderr)
        a = Author.query.filter(Author.name==b_author).one()
        book  =  Book.query.filter(Book.title==b_title).one()
        print('book_list : {}'.format(book), file=sys.stderr)
        if b_new_title != "" and b_new_price != "":
            book.price = b_new_price
            book.title = b_new_title
            db.session.add(book)
            db.session.commit()
        return redirect(url_for('one_author', id=a.id))
    return render_template(
        "modify_book.html",
        form=f
    )


@app.route("/save/author/", methods=("POST",))
def save_author():
    a = None
    f = AuthorForm()
    if f.id.data != "":
        id = int(f.id.data)
        a = get_author(id)
    else:
        a = Author(name=f.name.data)
        db.session.add(a)
    if f.validate_on_submit():
        a.name = f.name.data
        db.session.commit()
        id = a.id
        return redirect(url_for('one_author', id=a.id))
    return render_template(
        "edit_author.html",
        author=a, form=f
    )


class LoginForm(FlaskForm):
    username = StringField('Username')
    password = PasswordField('Password')

    def get_authenticated_user(self):
        user = User.query.get(self.username.data)
        if user is None:
            return None
        m = sha256()
        m.update(self.password.data.encode())
        passwd = m.hexdigest()
        return user if passwd == user.password else None


@app.route("/login/", methods=("GET", "POST",))
def login():
    f = LoginForm()
    if f.validate_on_submit():
        user = f.get_authenticated_user()
        if user:
            login_user(user)
            return redirect(url_for("home"))
    return render_template("login.html", form=f)


@app.route("/logout/")
def logout():
    logout_user()
    return redirect(url_for('home'))
