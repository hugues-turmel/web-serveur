import os.path
from .app import db
from flask_login import UserMixin
from .app import login_manager

class Author(db.Model):
    id      = db.Column(db.Integer, primary_key=True)
    name    = db.Column(db.String(100))
    def __repr__(self):
        return "<Author (%d) %s>" % (self.id, self.name)

class Book(db.Model):
    id          = db.Column(db.Integer, primary_key=True) #Clé primaire
    author_id   = db.Column(db.Integer, db.ForeignKey("author.id")) #Clé étrangère vers la table Author
    author      = db.relationship("Author", backref=db.backref("books", lazy="dynamic")) #Author.books permettra de voir les livres écrient par Author, lazy -> ne calcul la requete que sur demande
    price       = db.Column(db.Float)
    title       = db.Column(db.String(100))
    img         = db.Column(db.String(256))
    def __repr__(self):
        return "<Book (%d) %s>" % (self.id, self.title)

def get_sample():
    return Book.query.limit(24).all() #Requete des 10 premiers éléments correspondant a la requete

def get_all_author():
    return Author.query.all()

def get_all_book():
    return Book.query.all()
    
def get_book_detail(bookid):
    return Book.query.get_or_404(bookid)

def get_author(id):
    return Author.query.get_or_404(id)

def exist_author(name):
    return Author.query.filter(Author.name==name).one()

"""def get_sample(debut=0, nb=)
    return Author.query.offset(debut,nb).one()"""

class User(db.Model, UserMixin):
    username = db.Column(db.String (50) , primary_key =True)
    password = db.Column(db.String (64))

    def get_id(self):
        return self.username

@login_manager.user_loader
def load_user(username):
    return User.query.get(username)