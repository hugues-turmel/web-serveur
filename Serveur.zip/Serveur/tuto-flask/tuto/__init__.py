from .app import app,db
import tuto.views
import tuto.models
import tuto.commands
